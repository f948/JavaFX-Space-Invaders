/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package space.invaders;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class SpaceInvaders extends Application {
    
    
    static Canvas canvas = new Canvas(800,600);
    static GraphicsContext context = canvas.getGraphicsContext2D(); 
    static Group root = new Group(canvas);
    static Scene scene = new Scene(root, 800, 600);
    Timer timer = new Timer();
    static Random rand = new Random();
    
    final static Image alienImg = new Image("https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTQ2-TXQigpjy_uIz7iDdIX-_lgazRL2s4wvJ9jwwjzydWRK_-RLLlXeLnFSzkfoOfKbppVPZkiqoQpIZF-8WRkwgF2IJxj_OrkqA&usqp=CAU&ec=45690275");   
    final static Image playerImg = new Image("https://davidrroberts.files.wordpress.com/2016/10/player1.png?w=640"); 
    final static Image playerBulletImg = new Image("https://ih1.redbubble.net/image.488334907.8178/flat,1000x1000,075,f.u2.jpg"); 
    final static Image alienBulletImg = new Image("https://www.logolynx.com/images/logolynx/75/759cf8ab87b3c53d394d77fb4ca26ceb.jpeg");  
    final static Image barrierImg = new Image("https://i.imgur.com/eAok2Eg.png");
    
    static int row,col,i,j,num;
    static Ship playerShip;
    static ArrayList<Ship> alienShips = new ArrayList<>();
    static ArrayList<Bullet> playerBullets = new ArrayList<>();
    static ArrayList<Bullet> alienBullets = new ArrayList<>();
    final static Barrier [] barriers={new Barrier(150,400),new Barrier(350,400),new Barrier(550,400)};
    
    static int alienFleetLeftX=100,alienFleetRightX=700;
    static String alienFleetDirection="right";
    static int numAliensLeft=60;
    static boolean restart=false,playerCanFire=true;
    static int level=1;

    public static class Ship{
	
        int startX;
        int startY;
        boolean hit;

        
	public Ship(int x,int y){
					
            this.startX=x;
            this.startY=y;
            this.hit=false;
         
	}
	
    }
    
    // class that creates bullets 
				
    public static class Bullet{
	
        int startX;
        int startY;
        boolean hit;
     
        
	public Bullet(int x,int y){
					
            this.startX=x;
            this.startY=y;
            this.hit=false;
           
	}
    }
    
    // class that creates barriers
     public static class Barrier{
	
        int startX;
        int startY;
        int hits;

        
	public Barrier(int x,int y){
					
            this.startX=x;
            this.startY=y;
            this.hits=0;
         
	}
	
    }
     
    public static void startLevel(){
        
        // clear all arrays 
        playerBullets.clear();
        alienBullets.clear();
        alienShips.clear();
        
        // create player ship 
	playerShip = new Ship(400,550);
				
	// create alien ships 
        for(row=0;row<5;row++){
            for(col=0;col<12;col++){
                alienShips.add(new Ship(100+col*50,75+row*50));
            }
        }
        
        // reset all barrier hits to 0
        for(i=0;i<=2;i++){
            barriers[i].hits=0;
        }
        
        numAliensLeft=60;
        alienFleetDirection="right";
        alienFleetLeftX=100;
        alienFleetRightX=700;
        
        // level up or not 
        if(playerShip.hit || level == 6){
            playerShip.hit=false;
        }
        
        else if(!playerShip.hit){
            level++;
        }
    }
    
    public static void updateScreen(){
        
        // clear original screen
	context.clearRect(0,0,800,600);
				
	// redraw background 
	context.setFill(Color.BLACK);
	context.fillRect(0,0,800,600);
        
        if(!playerShip.hit){
				
            // draw player ship 
            
            context.drawImage(playerImg,playerShip.startX,playerShip.startY,50,50);

					
	}
        
        // draw player bullets 
	for(i=0;i<=playerBullets.size()-1;i++){
					
            if(!playerBullets.get(i).hit){
					
		// draw player bullet
						
		context.drawImage(playerBulletImg,playerBullets.get(i).startX,playerBullets.get(i).startY,20,20);
		
                // check if barrier is hit 
                for(j=0;j<=2;j++){
                    
                    if( barriers[j].hits<8 && barriers[j].startX<playerBullets.get(i).startX+20 && barriers[j].startX+100>playerBullets.get(i).startX && barriers[j].startY<playerBullets.get(i).startY+20 && barriers[j].startY+100>playerBullets.get(i).startY){
                        barriers[j].hits++;
                        playerBullets.get(i).hit=true;
                        
                        
                    }
                }
					
                
					
		// check if alien ship is hit
                for(j=0;j<=alienShips.size()-1;j++){
						
                    // case when alien ship is hit 
                    if(Math.pow(((playerBullets.get(i).startX+10)- (alienShips.get(j).startX+25)),2) +Math.pow(((playerBullets.get(i).startY)- (alienShips.get(j).startY+25)),2) <= 625 && !alienShips.get(j).hit){
                   
                        alienShips.get(j).hit=true;
                        playerBullets.get(i).hit=true;
                        numAliensLeft--;
                        
                        if(numAliensLeft == 0){
                            restart=true;
                        }
                    }
					
                }			
		
                
              
            // update player bullet position 
            playerBullets.get(i).startY-=40;
            
            }
	}
                                
        
        
        // draw alien bullets 
	for(i=0;i<=alienBullets.size()-1;i++){
					
            if(!alienBullets.get(i).hit){
					
		// draw alien bullet
					
		context.drawImage(alienBulletImg,alienBullets.get(i).startX,alienBullets.get(i).startY,20,20);
		
                // check if barrier is hit 
                for(j=0;j<=2;j++){
                    
                    if( barriers[j].hits<8 && barriers[j].startX<alienBullets.get(i).startX+20 && barriers[j].startX+100>alienBullets.get(i).startX && barriers[j].startY<alienBullets.get(i).startY+20 && barriers[j].startY+100>alienBullets.get(i).startY){
                        barriers[j].hits++;
                        alienBullets.get(i).hit=true;
                        
                        
                    }
                }
            
					
                // check if player ship is hit 
					
						
                if(Math.pow(((alienBullets.get(i).startX+10) - (playerShip.startX+25)),2) +Math.pow(((alienBullets.get(i).startY+20) - (playerShip.startY)),2) <= 625 && !alienBullets.get(i).hit){
							
                    alienBullets.get(i).hit=true;
                    playerShip.hit=true;
						
                    restart=true;
                }
	
					
            // update alien bullet position 
            alienBullets.get(i).startY+=10;
            }
	}
        
         // draw alien ships 

	for(i=0;i<=alienShips.size()-1;i++){
					
            if(!alienShips.get(i).hit){
					
		// draw alien ship 
					
		context.drawImage(alienImg,alienShips.get(i).startX,alienShips.get(i).startY,40,40);
		
                if(alienFleetDirection=="left"){
                    alienShips.get(i).startX-=2;
                }
                else if(alienFleetDirection=="right"){
                    alienShips.get(i).startX+=2;
                }
            }
				
	}
        
        // draw barriers
        for(i=0;i<=2;i++){
            if(barriers[i].hits<8){
                context.drawImage(barrierImg,barriers[i].startX,barriers[i].startY,100,100);
            }
        }
        
        if(alienFleetDirection=="left"){
            alienFleetLeftX-=2;
            alienFleetRightX-=2;
        }
        
        else if(alienFleetDirection=="right"){
            alienFleetLeftX+=2;
            alienFleetRightX+=2;
        }
        
        // turn alien fleet around 
        if(alienFleetDirection=="left" && alienFleetLeftX<=0){
            alienFleetDirection="right";
        }
        else if(alienFleetDirection=="right" && alienFleetRightX>=800){
            alienFleetDirection="left";
        }
        
        deleteObjects();
        
        // restart game or not 
        if(restart){
            
            startLevel();
        }
        
        restart=false;
    }
    
    public static void enemyFire(){
        
        for(i=0;i<=alienShips.size()-1;i++){
					
            if(!alienShips.get(i).hit){

		num = rand.nextInt(70-10*level);
				
                // case when alien ship fires 
		if(num == 0){
						
                    // create new bullet object for alien 
                 
                    alienBullets.add(new Bullet(alienShips.get(i).startX,alienShips.get(i).startY+40));
		}
            }
	}
    }
    
    public static void deleteObjects(){
        
        for(i=0;i<=playerBullets.size()-1;i++){
            if(playerBullets.get(i).hit || playerBullets.get(i).startY<=0){
                playerBullets.remove(playerBullets.get(i));
            }
        }
        
        for(i=0;i<=alienBullets.size()-1;i++){
            if(alienBullets.get(i).hit || alienBullets.get(i).startY>=600){
                alienBullets.remove(alienBullets.get(i));
            }
        }
        
        for(i=0;i<=alienShips.size()-1;i++){
            if(alienShips.get(i).hit || alienShips.get(i).startY>=600){
                alienShips.remove(alienShips.get(i));
            }
        }
    }
    
    @Override
    public void start(Stage primaryStage){
        
       startLevel();
        
        // control
	scene.addEventFilter(KeyEvent.KEY_PRESSED, key -> {
            
            if (key.getCode() == KeyCode.A && 0<playerShip.startX) {
		playerShip.startX-=25;
            }
            
	    if (key.getCode() == KeyCode.D && playerShip.startX+50<800) {
		playerShip.startX+=25;
	    }
            
            if (key.getCode() == KeyCode.W) {
                
                if(playerCanFire){
                    playerBullets.add(new Bullet(playerShip.startX+15,530));
                    playerCanFire=false;
                
                
                    timer.schedule(new TimerTask() {

                     @Override
                     public void run() {
                            playerCanFire=true;
                        }
                    
		
                
                    },1000);
                
                }
            }
        });
     
        
     
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                updateScreen();
            }
        },0,50);
        
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                enemyFire();
            }
        },0,1600-1*120*level);
        
        primaryStage.setTitle("Space Invaders");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
